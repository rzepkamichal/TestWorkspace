package application;


public class Coefficients  {
	
	private double[] coeffA,coeffB,coeffC,coeffD;
	private int numberOfEquations;
	
	public Coefficients(int numberOfEquations){
		this.numberOfEquations=numberOfEquations;
	}


	
	

	

}
