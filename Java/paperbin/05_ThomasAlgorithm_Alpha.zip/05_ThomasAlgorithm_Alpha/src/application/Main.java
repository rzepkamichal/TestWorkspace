package application;
	
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
public class Main extends Application {
	
	private GridPane RWelcomeGrid,RCalculateGrid;
	private Scene scene;
	private Button BApproveNumOfEq;	
	private Label LAskNumOfEq,TestLabel;
	private TextField TFNumOfEq;
	
	@Override
	public void start(Stage primaryStage) {
		try {
			RWelcomeGrid = new GridPane();//Create a GridPane for the "Welcome" layout
			RWelcomeGrid.setAlignment(Pos.TOP_CENTER);
			RWelcomeGrid.setHgap(20);//gap between columns
			RWelcomeGrid.setVgap(20);//gap between rows
			RWelcomeGrid.setPadding(new Insets(20,20,20,20));
			
				LAskNumOfEq=new Label("Podaj lczb� r�wna�:");//Set Label asking for the Number of Equations and add to GridPane
				LAskNumOfEq.setFont(new Font("Tahoma",20));
				RWelcomeGrid.add(LAskNumOfEq, 0, 4);
			
				TFNumOfEq=new TextField();//Set a Text Field to write the Number Of Equations into it and add to GridPane
				TFNumOfEq.setFont(new Font("Tahoma",15));
				TFNumOfEq.setMaxWidth(45);
				RWelcomeGrid.add(TFNumOfEq, 0, 5);
				RWelcomeGrid.setHalignment(TFNumOfEq, HPos.CENTER);
			
			
				BApproveNumOfEq=new Button("Zatwierd"+String.valueOf((char)(378)));//Set a button. On Click the app will get the Number Of Equations and will proove, if the user had given correct InputData
				BApproveNumOfEq.setFont(new Font("Tahoma",15));
				BApproveNumOfEq.setMinWidth(80);
				RWelcomeGrid.add(BApproveNumOfEq, 0, 6);
				RWelcomeGrid.setHalignment(BApproveNumOfEq, HPos.CENTER);
				
			RCalculateGrid=new GridPane();//Create a GridPane for the "Calculate" Layout
			RCalculateGrid.setAlignment(Pos.TOP_CENTER);
			RCalculateGrid.setHgap(20);//gap between columns
			RCalculateGrid.setVgap(20);//gap between rows
			RCalculateGrid.setPadding(new Insets(20,20,20,20));
			
				TestLabel=new Label("Siemanko");
				RCalculateGrid.add(TestLabel, 0, 0);
			
			scene = new Scene(RWelcomeGrid,400,400);
			primaryStage.setTitle("Thomas Algorithm");
			primaryStage.setScene(scene);
			primaryStage.show();
			
			
			
			BApproveNumOfEq.setOnAction(new EventHandler<ActionEvent>(){
				@Override
				public void handle(ActionEvent arg0) {
					
					scene.setRoot(RCalculateGrid);
					Coefficients coeff=new Coefficients(Integer.parseInt(TFNumOfEq.getText()));
				}
			});
			
			
			
			
			
			
			
			
			
			
		
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}

	
}
