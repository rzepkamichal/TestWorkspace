package application;

public interface ISetCoefficients {

	
	public void setCoeffa();
	public void setCoeffb();
	public void setCoeffc();
	public void setCoeffd();
	
		
	
}
	
	
