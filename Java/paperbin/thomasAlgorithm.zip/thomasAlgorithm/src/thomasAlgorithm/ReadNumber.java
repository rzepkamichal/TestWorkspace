package thomasAlgorithm;
import java.util.Scanner;
public class ReadNumber {
	
	static Scanner scan=new Scanner(System.in);
	
	public static int Read(){
			System.out.println("Podaj liczb� r�wna�:");
		return scan.nextInt();
	}
}
