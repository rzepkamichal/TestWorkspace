package thomasAlgorithm;
import java.util.InputMismatchException;
public class main {
public static void main(String[] args) {
	
	Coefficients coefficients=new Coefficients();
	try{
		int numberOfEquations=ReadNumber.Read();
		coefficients.Set_a(numberOfEquations);
		coefficients.Set_b(numberOfEquations);
		coefficients.Set_c(numberOfEquations);
		coefficients.Set_d(numberOfEquations);
		
		coefficients.CalculateBetaGamma(numberOfEquations);
		coefficients.CalculateSolution(numberOfEquations);
		
	}catch(InputMismatchException e){
			System.out.println("B��d! Niepoprawne dane wej�ciowe- nale�y poda� liczb� naturaln�.");
	}
	
	}

}
