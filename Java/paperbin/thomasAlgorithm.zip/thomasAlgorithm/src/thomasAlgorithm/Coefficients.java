package thomasAlgorithm;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Coefficients {
	
	Scanner scan=new Scanner(System.in);
	
	private List<Double> coefficient_a=new ArrayList<Double>();
	private List<Double> coefficient_b=new ArrayList<Double>(); 
	private List<Double> coefficient_c=new ArrayList<Double>(); 
	private List<Double> coefficient_d=new ArrayList<Double>();
	private List<Double> beta=new ArrayList<Double>();
	private List<Double> gamma=new ArrayList<Double>();
	
	public void Set_a(int n) {
		coefficient_a.add(0.0);
		for(int i=1;i<n;i++){
				System.out.println("Podaj warto�� wsp�czynnika a"+(i+1)+":");
			coefficient_a.add(scan.nextDouble());
		}
	}
	
	public double Get_a(int i){
		return coefficient_a.get(i);
	}
	
	public void Set_b(int n){
		for(int i=0;i<n;i++){
				System.out.println("Podaj warto�� wsp�czynnika b"+(i+1)+":");
			coefficient_b.add(scan.nextDouble());
		}
	}
	
	public double Get_b(int i){
		return coefficient_b.get(i);
	}
	
	public void Set_c(int n) {
		
		for(int i=0;i<n-1;i++){
				System.out.println("Podaj warto�� wsp�czynnika c"+(i+1)+":");
			coefficient_c.add(scan.nextDouble());
		}
		coefficient_c.add(0.0);
	}
	
	public double Get_c(int i){
		return coefficient_c.get(i);
	}
	
	public void Set_d(int n){
		
		for(int i=0;i<n;i++){
				System.out.println("Podaj warto�� wsp�czynnika d"+(i+1)+":");
			coefficient_d.add(scan.nextDouble());
		}
	}
	
	public double Get_d(int i){
		return coefficient_d.get(i);
	}
	
	public double Get_beta(int i){
		return beta.get(i);
	}
	
	public double Get_gamma(int i){
		return gamma.get(i);
	}
	
	public void CalculateBetaGamma(int n){
		beta.add(-(Get_c(0))/Get_b(0));
		gamma.add((Get_d(0))/Get_b(0));
		
		for(int i=1;i<n;i++){
			if(i<n-1){
				beta.add(-(Get_c(i))/((Get_a(i)*Get_beta(i-1))+Get_b(i)));
			}
			gamma.add((Get_d(i)-(Get_a(i)*Get_gamma(i-1)))/((Get_a(i)*Get_beta(i-1))+Get_b(i)));
		}
	}
	
	public void CalculateSolution(int n){
		double[] solution=new double[n];
		solution[n-1]=Get_gamma(n-1);
			System.out.printf("x%d= %.3f",1,solution[n-1]);
		for(int i=n-2;i>=0;i--){
			solution[i]=(Get_beta(i)*solution[i+1])+Get_gamma(i);
				System.out.printf("\nx%d= %.3f", (n-i),solution[i]);
		}
		
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
